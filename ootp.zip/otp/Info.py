#Twilio
account_sid = 'AC10fdaafb587bdc127fc975597aa4d122'
auth_token = '65de3f50fdafb3da52d083169175283c'
twilionumber = '+923261451980'
twiliosmsnumber = '+923261451980'

#Telegram Bot Token
API_TOKEN = "6885408734:AAGxH5_Z9jTYSh_RpKa7U2803layDWS2MTk" 

#Host URL
callurl = 'https://2b7a-37-111-181-169.ngrok-free.app'
twiliosmsurl = 'https://2b7a-37-111-181-169.ngrok-free.app/sms'









